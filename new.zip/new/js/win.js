
// Define an array of trivia questions and answers
const trivia = [
  {
    question: "What is the largest planet in our solar system?",
    answers: [
      "Jupiter",
      "Saturn",
      "Neptune"
    ],
    correctAnswer: 1
  },
  {
    question: "Which galaxy is our solar system a part of?",
    answers: [
      "Andromeda Galaxy",
      "Milky Way Galaxy",
      "Sombrero Galaxy"
    ],
    correctAnswer: 2
  },
  {
    question: "Which planet is known as the 'Red Planet'?",
    answers: [
      "Venus",
      "Mars",
      "Jupiter"
    ],
    correctAnswer: 1
  }
];

// Get references to HTML elements
const questionEl = document.getElementById("question");
const answer1El = document.getElementById("answer1");
const answer2El = document.getElementById("answer2");
const answer3El = document.getElementById("answer3");
const resultEl = document.getElementById("result");

let currentQuestionIndex = 0;

// Function to update the question and answer buttons
function displayQuestion() {
  questionEl.textContent = trivia[currentQuestionIndex].question;
  answer1El.textContent = trivia[currentQuestionIndex].answers[0];
  answer2El.textContent = trivia[currentQuestionIndex].answers[1];
  answer3El.textContent = trivia[currentQuestionIndex].answers[2];
}

// Function to check the user's answer
function checkAnswer(answerIndex) {
  if (answerIndex === trivia[currentQuestionIndex].correctAnswer) {
    resultEl.textContent = "Correct!";
  } else {
    resultEl.textContent = "Incorrect.";
  }
 
  // Move to the next question
  currentQuestionIndex++;
 
  // If there are no more questions, end the game
  if (currentQuestionIndex === trivia.length) {
    questionEl.textContent = "Game over.";
    answer1El.style.display = "none";
    answer2El.style.display = "none";
    answer3El.style.display = "none";
  } else {
    displayQuestion();
  }
}

// Start the game by displaying the first question
displayQuestion();


Slider
// Get references to HTML elements
const sliderContainer = document.getElementById("slider-container");
const slider = document.getElementById("slider");

// Set initial position of the slider
let currentPosition = 0;
slider.style.left = currentPosition + "px";

// Function to move the slider
function moveSlider(distance) {
  currentPosition += distance;
  slider.style.left = currentPosition + "px";
}

// Event listeners for clicking on the slider container
sliderContainer.addEventListener("mousedown", function(event) {
  // Record the starting position of the mouse
  const startingX = event.clientX;
 
  // Event listener for moving the mouse
  function onMouseMove(event) {
    // Calculate the distance the mouse has moved
    const distance = event.clientX - startingX;
   
    // Move the slider by the distance the mouse has moved
    moveSlider(distance);
   
    // Update the starting position of the mouse
    startingX = event.clientX;
  }
 
  // Event listener for releasing the mouse button
  function onMouseUp(event) {
    // Remove the event listeners
    document.removeEventListener("mousemove", onMouseMove);
    document.removeEventListener("mouseup", onMouseUp);
  }
 
  // Add the event listeners
  document.addEventListener("mousemove", onMouseMove);
  document.addEventListener("mouseup", onMouseUp);
});

// Get references to HTML elements
const sliderContainer = document.getElementById("slider-container");
const slider = document.getElementById("slider");

// Set initial position of the slider
let currentPosition = 0;
slider.style.left = currentPosition + "px";

// Function to move the slider
function moveSlider(distance) {
  currentPosition += distance;
  slider.style.left = currentPosition + "px";
}

// Event listeners for clicking on the slider container
sliderContainer.addEventListener("mousedown", function(event) {
  // Record the starting position of the mouse
  const startingX = event.clientX;
 
  // Event listener for moving the mouse
  function onMouseMove(event) {
    // Calculate the distance the mouse has moved
    const distance = event.clientX - startingX;
   
    // Move the slider by the distance the mouse has moved
    moveSlider(distance);
   
    // Update the starting position of the mouse
    startingX = event.clientX;
  }
 
  // Event listener for releasing the mouse button
  function onMouseUp(event) {
    // Remove the event listeners
    document.removeEventListener("mousemove", onMouseMove);
    document.removeEventListener("mouseup", onMouseUp);
  }
 
  // Add the event listeners
  document.addEventListener("mousemove", onMouseMove);
  document.addEventListener("mouseup", onMouseUp);
});



