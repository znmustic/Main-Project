
const trivia = [
  {
    question: "What is the largest planet in our solar system?",
    answers: [
      "Jupiter",
      "Saturn",
      "Neptune"
    ],
    correctAnswer: 1
  },
  {
    question: "Which galaxy is our solar system a part of?",
    answers: [
      "Andromeda Galaxy",
      "Milky Way Galaxy",
      "Sombrero Galaxy"
    ],
    correctAnswer: 2
  },
  {
    question: "Which planet is known as the 'Red Planet'?",
    answers: [
      "Venus",
      "Mars",
      "Jupiter"
    ],
    correctAnswer: 1
  },
  {
    question: "What is the name of the first satellite launched into space?",
    answers: [
      "Sputnik 1",
      "Sparnik 2",
      "Bhaskara"
    ],
    correctAnswer: 1
  },
  {
    question: "What was the name of the first human to journey into space?",
    answers: [
      "Neil Armstrong",
      "Edwin E. Aldrin",
      "Yuri Gagarin"
    ],
    correctAnswer: 3
  },
  {
    question: "What is the name of the spacecraft that carried Neil Armstrong and Buzz Aldrin to the moon?",
    answers: [
      "Odyssey",
      "Apollo 11",
      "Orbiter"
    ],
    correctAnswer: 2
  },
  {
    question: "How many planets are there in our solar system?",
    answers: [
      "Two",
      "Four",
      "Eight"
    ],
    correctAnswer: 3
  },
  {
    question: "What is the largest planet in our solar system?",
    answers: [
      "Jupiter",
      "Saturn",
      "Mars"
    ],
    correctAnswer: 1
  },
  {
    question: "What is the name of the first dog to go into space?",
    answers: [
      "Laika",
      "Spot",
      "Rover"
    ],
    correctAnswer: 1
  },
  {
    question: "Who was the first person to walk on the moon?",
    answers: [
      "Mae Jemison",
      "Neil Armstrong",
      "Edwin E. Aldrin"
    ],
    correctAnswer: 2
  },
  {
    question: "What is the name of the closest star to our sun?",
    answers: [
      "Proxima Centauri",
      "Andromeda",
      "Condor"
    ],
    correctAnswer: 1
  },
  {
    question: "What is the name of the largest volcano in our solar system?",
    answers: [
      "Mauna Kea",
      "Tamu Massif",
      "Olympus Mons"
    ],
    correctAnswer: 3
  },
  {
    question: "What is the name of the largest moon in our solar system?",
    answers: [
      "Ganymede",
      "Europa",
      "Enceladus"
    ],
    correctAnswer: 1
  },
  {
    question: " What is the name of the first American woman in space?",
    answers: [
      "Sally Ride",
      "Christa McAuliffe",
      "Mae Jemison"
    ],
    correctAnswer: 1
  },
  {
    question: "What is the name of the spacecraft that carried the first privately-funded crew to space?",
    answers: [
      "Blue Origin New Shepard",
      "SpaceX Crew Dragon",
      "Virgin Galactic SpaceShipTwo"
    ],
    correctAnswer: 2
  },
  {
    question: " What is the name of the phenomenon that causes a sudden increase in the brightness of a star?",
    answers: [
      "Supernova",
      "Black hole",
      "Quasar"
    ],
    correctAnswer: 1
  },
  {
    question: "What is the name of the planet that was once considered the ninth planet in our solar system?",
    answers: [
      "Eris",
      "Ceres",
      "Pluto"
    ],
    correctAnswer: 3
  },
  {
    question: "What is the name of the largest asteroid in our solar system?",
    answers: [
      "Vesta",
      "Pallas",
      "Ceres"
    ],
    correctAnswer: 3
  },
  {
    question: "What is the name of the largest canyon in our solar system?",
    answers: [
      "Grand Canyon",
      "Valles Marineris",
      "Ithaca Chasma"
    ],
    correctAnswer: 2
  },
  {
    question: "What is the name of the first space telescope launched into orbit?",
    answers: [
      "Hubble Space Telescope",
      "Chandra X-ray Observatory",
      "Spitzer Space Telescope"
    ],
    correctAnswer: 1
  },
  {
    question: "What is the name of the space probe that explored the planet Saturn and its moons?",
    answers: [
      "Voyager 1",
      "Cassini-Huygens",
      "New Horizons"
    ],
    correctAnswer: 2
  },
  {
    question: "What is the name of the bright streaks of light that sometimes appear in the night sky?",
    answers: [
      "Stars",
      "Comets",
      "Meteors"
    ],
    correctAnswer: 3
  },
  {
    question: "What is the name of the force that pulls objects towards each other?",
    answers: [
      "Gravity",
      "Magnetism",
      "Friction"
    ],
    correctAnswer: 1
  },
  {
    question: "What is the name of the planet that is closest to the sun?",
    answers: [
      "Venus",
      "Mercury",
      "Mars"
    ],
    correctAnswer: 2
  },
  {
    question: "What is the name of the brightest star in the night sky?",
    answers: [
      "Polaris",
      "Sirius",
      "Vega"
    ],
    correctAnswer: 2
  },
  {
    question: "hat is the name of the constellation that contains the Big Dipper?",
    answers: [
      "Orion",
      "Ursa Major",
      "Cygnus"
    ],
    correctAnswer: 2
  },
  {
    question: "What is the name of the planet with the Great Red Spot??",
    answers: [
      "Saturn",
      "Neptunee",
      "Jupiter"
    ],
    correctAnswer: 1
  },
  {
    question: "What is the name of the imaginary line that runs through the earth's poles?",
    answers: [
      "Equator",
      "Tropic of Cancer",
      "Prime Meridian"
    ],
    correctAnswer: 3
  },
  {
    question: "What is the name of the second planet from the sun?",
    answers: [
      "Mars",
      "Venus",
      "Uranus"
    ],
    correctAnswer: 2
  },
  {
    question: "What is the name of the NASA mission that successfully landed humans on the moon?",
    answers: [
      "Mercury 3",
      "Gemini 7",
      "Apollo 11"
    ],
    correctAnswer: 3
  },
];
function displayQuestion() {
  questionEl.textContent = trivia[currentQuestionIndex].question;
  answer1El.textContent = trivia[currentQuestionIndex].answers[0];
  answer2El.textContent = trivia[currentQuestionIndex].answers[1];
  answer3El.textContent = trivia[currentQuestionIndex].answers[2];
}


function checkAnswer(answerIndex) {
  if (answerIndex === trivia[currentQuestionIndex].correctAnswer) {
    resultEl.textContent = "Correct!";
    resultEl.style.color = "green";
    correctAnswers++;
  } else {
    resultEl.textContent = "Incorrect.";
    resultEl.style.color = "red";
  }


  currentQuestionIndex++;


  if (currentQuestionIndex === trivia.length) {
    const totalScore = `${correctAnswers}/${trivia.length}`;
    if (correctAnswers === trivia.length) {
      scoreEl.textContent = `Congratulations! You got ${totalScore}!`;
      resultEl.textContent = "";
      questionEl.textContent = "";
    } else {
      scoreEl.textContent = `You got ${totalScore}. Keep trying!`;
      resultEl.textContent = "";
      questionEl.textContent = "";
      button.textContent = "Try Again";
    }
    answer1El.style.display = "none";
    answer2El.style.display = "none";
    answer3El.style.display = "none";
  } else {
    displayQuestion();
  }
}

let questionEl;
let answer1El;
let answer2El;
let answer3El;
let resultEl;
let button;
let currentQuestionIndex = 0;
let correctAnswers = 0;
let scoreEl;

window.addEventListener("DOMContentLoaded", (event) => {

  questionEl = document.getElementById("question");
  answer1El = document.getElementById("answer1");
  answer2El = document.getElementById("answer2");
  answer3El = document.getElementById("answer3");
  resultEl = document.getElementById("result");
  button = document.getElementById("button");
  scoreEl = document.getElementById("score");

  button.addEventListener("click", (event) => {
    if (answer1El.nextElementSibling.checked) {
      checkAnswer(1);
    }
    if (answer2El.nextElementSibling.checked) {
      checkAnswer(2);
    }
    if (answer3El.nextElementSibling.checked) {
      checkAnswer(3);
    }
  });
  
  


  displayQuestion();
});